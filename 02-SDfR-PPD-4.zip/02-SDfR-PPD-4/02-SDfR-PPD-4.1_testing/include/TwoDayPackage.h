//==============================================================
// Filename    : TwoDayPackage.h
// Authors     : Vlad Malaxa s2726254, Ricardo Diaz s3681548
// Group       : PPD Group 2
// License     :  N.A. or opensource license like LGPL
// Description : This code consists of the TwoDayPackage class implementation,
// which inherits from the Package class.
//==============================================================

#ifndef TWODAYPACKAGE_H
#define TWODAYPACKAGE_H

#include "Package.h"

class TwoDayPackage : public Package {
public:
    TwoDayPackage(std::string sName, std::string sAddr,
                  std::string rName, std::string rAddr,
                  double w);
};

#endif